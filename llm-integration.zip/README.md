# Groq Writing Assistant for Thunderbird

A Thunderbird add-on that helps improve your email writing style using the Groq AI API.

## Features

- Adds a button to the Thunderbird compose window
- Uses Groq AI to improve writing style while maintaining the original message
- Secure API key storage
- Easy-to-use interface

## Installation

1. Download the latest release of the add-on
2. Open Thunderbird
3. Go to Tools > Add-ons
4. Click the gear icon and select "Install Add-on From File"
5. Select the downloaded add-on file
6. Restart Thunderbird when prompted

## Setup

1. After installation, you'll be prompted to enter your Groq API key
2. If you need to change the API key later:
   - Go to Tools > Add-ons
   - Find "Groq Writing Assistant"
   - Click "Options"
   - Enter your new API key and click "Save"

## Usage

1. Compose a new email as usual
2. Click the "Improve Writing Style" button in the compose window
3. Wait for the AI to process your text
4. The improved version will replace your original text
5. Review the changes and send your email

## Requirements

- Thunderbird 78.0 or later
- A valid Groq API key

## Privacy

- Your API key is stored securely in your Thunderbird profile
- Your email content is only sent to Groq's API when you click the improve button
- No data is stored or shared with third parties

## Support

If you encounter any issues or have questions, please open an issue in the GitHub repository.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
